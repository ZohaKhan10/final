const ProductModel = require('../models/product');
const Category = require('../models/type');


//for list-products
exports.getProducts = (req, res, next) => {
  const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn : false;
  const user=req.session.isAdmin ? req.session.isAdmin :false;
    ProductModel
    .find()
    .populate('categoryId')
    .then(products => {
        console.log('products', products);
        res.render('list-products', {
            pageTitle: "My Store - List Products",
            products: products,
            isAuthenticated: isAuthenticated,
            user:user
      

        });
    });
}
//show add product form/page
exports.getAddProducts = (req, res, next) => {
  const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn : false;
  const user=req.session.isAdmin ? req.session.isAdmin :false;
    Category
    .find()
    .then(categories => {
      console.log('product', categories);
        res.render('add-product', {
            pageTitle: "My Store - Add Products",
            categories: categories,
            isAuthenticated: isAuthenticated,
            user:user
        })
    });
}

//to save new product in db
exports.postProducts = (req, res, next) => {
    const product = new ProductModel({
        title: req.body.name,
        price: +req.body.price,
        imageUrl: req.body.imageUrl,
        categoryId: req.body.categoryId
    });
    product.save().then(addedProduct => {
        res.redirect('/shopping/list-products');
    });
}



exports.getEditProduct= (req, res, next) => {
  const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn : false;
  const user=req.session.isAdmin ? req.session.isAdmin :false;
    const editMode = req.query.edit;
    if (!editMode) {
      return res.redirect('/shopping/list-products');
    }
    const productId = req.params.productId.split("&")[0];
    const categoryId = req.params.productId.split("&")[1];
    
        Category
        .find()
        .then(categories =>{
        ProductModel.findById(productId)
        
        .then(product => {
            if (!product) {
                return res.redirect('/');
            }
          res.render('edit-products', {
          pageTitle: 'Edit product',
          path: '/shopping/edit-product',
          editing: editMode,
          product: product,
          categories: categories,
          isAuthenticated: isAuthenticated,
          user:user
         
        });
      })
    })
      .catch(err => console.log(err));
};

exports.postEditProduct = (req, res, next) => {
      // validate request
      if (!req.body) {
        res.status(400).send({ message: "Content can not be empty!" });
        return;
    }
     const productId = req.body.productId;
    

     ProductModel.findByIdAndUpdate(productId, {
        title: req.body.name,
        price: req.body.price,
        imageUrl: req.body.imageUrl,
        categoryId: req.body.categoryId
    })
      .then(() => {
        console.log('UPDATED PRODUCT!');
        res.redirect('/shopping/list-products');
      })
      .catch(err => console.log(err));
   
  };




exports.deleteProduct =  (req, res, next) => {
    const ProductId = req.body.productId;
    ProductModel.findByIdAndDelete(ProductId)
      .then(() => {
        console.log('DESTROYED Product');
        res.redirect('/shopping/list-products');
      })
      .catch(err => console.log(err));
  
  };



