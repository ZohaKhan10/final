const express = require('express');

const categoryController = require('../controllers/category-controller');

const router = express.Router();

//on click to 'Add category' render ADD category page
router.get('/add-category', categoryController.getAddCategory);
//On submit Add new category to db
router.post('/add-category', categoryController.postCategory);


router.get('/list-categories', categoryController.getcategories);
module.exports = router;
