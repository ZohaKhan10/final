const express = require('express');
const bodyParser = require('body-parser');
const bcrypt = require("bcrypt");
const path = require('path');
const mongoose = require('mongoose');
const shoppingRoutes = require('./routes/shop-routes');
const categoryRoutes = require('./routes/category-routes');
const accountRoutes = require('./routes/account-routes');
const Type = require('./models/type');
const Product = require('./models/product');
const session = require('express-session');
const MongoDBStore = require('connect-mongodb-session')(session);
const User = require('./models/user');
const app = express();
const store = new MongoDBStore({
    uri:'mongodb://cmdlhrltx03:27017/warehouse',
    collection: 'sessions'
  });



app.use(bodyParser.urlencoded({extended: false}));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');
app.set('views', 'views');


app.use(
    session({
      secret: 'my secret',
      resave: false,
      saveUninitialized: false,
      store: store
    })
  );

// Register Routes 
app.use('/accounts', accountRoutes);
app.use('/shopping', shoppingRoutes);
app.use('/shopping', categoryRoutes);


// app.use((req, res, next) => {
//     res.render('not-found', {
//         pageTitle: 'Page not found!'
//     });
// });


app.use('/', (req, res) => {
    const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn : false;
    const user=req.session.isAdmin ? req.session.isAdmin :false;
    res.render('index', {

        pageTitle: 'Home Page',
        isAuthenticated: isAuthenticated,
        user:user
        

    })
});



// Set 404 View here
app.use((req, res) => {
    const isAuthenticated = req.session.isAuthenticated ? req.session.isAuthenticated : false;
    res.render('404', {
        pageTitle: 'Page not found',
        isAuthenticated: isAuthenticated
    })
});




mongoose.connect('mongodb://cmdlhrltx03:27017/warehouse', () => {

    // let password = "12345";


    // var hash = bcrypt.hashSync(password, 12);



       

    // const Admin1 = new User({
    //     firstName: 'Zoha',
    //     lastName: 'Khan',
    //     email:'zohamkhan10@gmail.com',
    //     password: hash,
    //     role: 'admin'

    // });
    // Admin1.save();
    
    app.listen(5000, () => {
        console.log('Started listening at port 5000.');
    });
});
