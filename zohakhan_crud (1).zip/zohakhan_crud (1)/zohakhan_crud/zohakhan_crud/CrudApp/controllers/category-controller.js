const Category = require('../models/type');
const mongodb = require('mongodb');


//for list-products
exports.getcategories = (req, res, next) => {
    const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn : false;
    Category
    .find()
    .then(categories => {
        console.log('categories', categories);
        res.render('list-categories', {
            pageTitle: "My Store - List categories",
            categories: categories,
            isAuthenticated: isAuthenticated
        });
    });
}







//show add category form/page
exports.getAddCategory = (req, res, next) => {
    const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn : false;
    Category
    .find()
    .then(categories => {
        res.render('add-category', {
            pageTitle: "Add Category",
            isAuthenticated: isAuthenticated
        })
    });
}
//to save new category in db
exports.postCategory = (req, res, next) => {
    // validate request
    if (!req.body) {
        res.status(400).send({ message: "Content can not be empty!" });
        return;
    }
    //create new category instance
    const category = new Category({
        title: req.body.title,
        description: req.body.description
    });
    //save it to data base
    category.save()
    .then(addedCategory => {
      console.log("Category Added ", addedCategory);
        res.redirect('/shopping/list-categories');
    })
    .catch(err => {
        res.status(500).send({ message: err.message || "Some error occurred while adding a new category" })
        });
}



