const userModel = require('../models/user');
const mongoose = require('mongoose');
const bcrypt = require("bcrypt");

exports.getSignupForm = (req, res) => {

    const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn : false;
   
        res.render('signup', {
            pageTitle: 'Create our account',
            isAuthenticated: isAuthenticated,
          

        });
    
}




exports.postSignupForm = async(req, res) => {
   
  // const hashpassword=await bcrypt.hash(req.body.password,12);

    const model = new userModel({
      
        _id: mongoose.Types.ObjectId(),
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        password: req.body.password,
        roles:req.body.Role,
       
    });
    // console.log(model.roles);
    model.save().then(addedCustomer => {
        res.redirect('/accounts/signin');
    });
}

exports.getSigninForm = (req, res) => {
    const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn : false;
    res.render('signin', {
        pageTitle: 'Login to your account',
        isAuthenticated: isAuthenticated
    });
}

exports.postSigninForm = (req, res) => {
    userModel.findOne({
        email: req.body.email,
        password: req.body.password,
        roles:req.body.Role
    })
    .then(user => {
        if(user) {
            req.session.isLoggedIn = true,
            req.session.user = user

            res.redirect('/');

        } else {
            res.redirect('/account/signin');
        }
    })
}


exports.postLogout = (req, res, next) => {
    req.session.destroy(err => {
      console.log(err);
      res.redirect('/');
    });
  };


