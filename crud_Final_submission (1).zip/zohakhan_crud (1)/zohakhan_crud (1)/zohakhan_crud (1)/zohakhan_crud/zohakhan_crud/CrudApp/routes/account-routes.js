const express = require('express');
const {check, body} = require('express-validator');
const userModel = require('../models/user');
const { 
    getSignupForm,
    postSignupForm,
    getSigninForm,
    postSigninForm,
    postLogout,
    getforgotpasswordForm,
   postforgotpasswordForm,
   getAdminForm,
   postAdminForm,
   getUsers,
} = require('../controllers/accounts-controller');

const router = express.Router();

router.get('/signup', getSignupForm);

router.post('/signup', 
check('firstName').contains().withMessage('Enter First Name'),
check('lastName').contains().withMessage('Enter LastName'),
check('email').isEmail().withMessage('Please enter a valid email address.').custom(async (email) => {
    const existingUser =
        await userModel.findOne({ email })
         
    if (existingUser) {
        throw new Error('Email already in use')
    }
}),
body('password', 'Please enter a password with only numbers and text and at least 5 characters.')
.isLength({min: 5})
.isAlphanumeric(),
postSignupForm)

router.get('/signin', getSigninForm);
router.post('/signin', postSigninForm);


router.get('/forgot-password', getforgotpasswordForm);
router.post('/forgot-password', postforgotpasswordForm);



router.get('/newUserByAdmin', getAdminForm);
router.post('/newUserByAdmin', postAdminForm);

router.get('/list-users',getUsers);
router.post('/logout', postLogout);


module.exports = router;














// router.post('/signup', check('email').isEmail().withMessage('Please enter a valid email address.').custom((value, {req}) => {
//     if(value.indexOf('test') > -1) throw new Error('This is a fobidden email address');
// }),
// body('password', 'Please enter a password with only numbers and text and at least 5 characters.')
// .isLength({min: 5})
// .isAlphanumeric(),
// body('confirmPassword').custom((value, {req}) => {
//     if(value !== req.body.password) throw new Error('Password doen not match.');
// }), postSignupForm)