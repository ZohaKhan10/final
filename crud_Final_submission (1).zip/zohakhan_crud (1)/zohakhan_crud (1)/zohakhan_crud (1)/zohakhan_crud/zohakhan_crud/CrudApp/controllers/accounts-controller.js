const userModel = require('../models/user');
const mongoose = require('mongoose');
const bcrypt = require("bcrypt");
const {validationResult} = require('express-validator');

exports.getSignupForm = (req, res) => {

    const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn : false;
    // const user=req.session.isAdmin ? req.session.isAdmin :false;
   
        res.render('signup', {
            pageTitle: 'Create our account',
            isAuthenticated: isAuthenticated,
            validationErrors: []

        });
    
}




exports.postSignupForm = (req, res) => {
    const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn : false;
  

   newPassword=req.body.password;
   confirmPassword=req.body.confirmPassword;
    if(newPassword!== confirmPassword){
        res.status(400).send({ message: "password does not match" });
        return;
      }
      const Password = req.body.confirmPassword;
      const hashpassword= bcrypt.hashSync(Password,12);

   const errors = validationResult(req);
   if(errors.isEmpty()) {
    const model = new userModel({
      
        _id: mongoose.Types.ObjectId(),
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        password: hashpassword,
        
       
    });
   
    
    model.save().then(addedCustomer => {
        res.redirect('/accounts/signin');
    });
}
else {
    res.render('signup', {
        path:'/signup',
        pageTitle: 'Signup',
        validationErrors: errors.array(),
        isAuthenticated: isAuthenticated
    })
}
}

exports.getSigninForm = (req, res) => {
    const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn : false;
    // const user=req.session.isAdmin ? req.session.isAdmin :false;
    res.render('signin', {
        pageTitle: 'Login to your account',
        isAuthenticated: isAuthenticated,
            // user:user
    });
}


exports.getforgotpasswordForm = (req,res) =>{
    const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn : false;
    res.render('forgot-password', {
        pageTitle: 'reset your password',
        isAuthenticated: isAuthenticated,
      
    });


}

exports.postforgotpasswordForm =( req,res) =>{


   newPassword=req.body.password;
   confirmPassword=req.body.confirmPassword;
    if(newPassword!== confirmPassword){
        res.status(400).send({ message: "password does not match" });
        return;
      }

    const Password = req.body.confirmPassword;
    const hashpassword= bcrypt.hashSync(Password,12);
 
    userModel.findOne({
        email: req.body.email,
        })
        .then(user => {

            userModel.findByIdAndUpdate( user,{
                password:hashpassword
            })
            .then(() => {
                res.redirect('/accounts/signin');
            })






        });

      
}


exports.postSigninForm = async (req, res) => {
 
    const Password = req.body.password;
    
     userModel.findOne({
    email: req.body.email,
    })
     
     .then (user => {
        if (!user) 
        return res.status(400).json({ msg: "User not exist" })
        if(user) {



              
             const valid=bcrypt.compareSync(Password, user.password);
         
                    if (!valid) {
                    return res.redirect('/accounts/signin');
                     }  
                    

                   

         
            const admin = (user.role =='admin') ? true : false;
         
            req.session.isLoggedIn = true,
            req.session.isAdmin = admin;
            req.session.user = user

            res.redirect('/');

        } else {
            res.redirect('/account/signin');
        }
    })

  
}


exports.postLogout = (req, res, next) => {
    req.session.destroy(err => {
      console.log(err);
      res.redirect('/');
    });
  };



  exports.getAdminForm = (req,res,next) =>
   {
    const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn : false;
    const user=req.session.isAdmin ? req.session.isAdmin :false;
     res.render('userbyadmin', {
        pageTitle: 'Insert new user',
        isAuthenticated: isAuthenticated,
        user:user,
      
    });



  };


  exports.postAdminForm =(req,res,next) =>
  {
    const hashpassword= bcrypt.hashSync(req.body.password,12);

    const model = new userModel({
      
        _id: mongoose.Types.ObjectId(),
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        password: hashpassword,
        role:req.body.Role,
       
    });
   
    
    model.save().then(addedCustomer => {
        res.redirect('/accounts/list-users');
    });

  }




  //for list-users
exports.getUsers = (req, res, next) => {
    const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn : false;
    const user=req.session.isAdmin ? req.session.isAdmin :false;
      userModel
      .find()
      .then(users => {
          res.render('list-users', {
              pageTitle: "My Store - List Users",
              isAuthenticated: isAuthenticated,
              users:users,
              user:user
        
  
          });
      });
  }