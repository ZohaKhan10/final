const userModel = require('../models/user');
const mongoose = require('mongoose');
const bcrypt = require("bcrypt");

exports.getSignupForm = (req, res) => {

    const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn : false;
    // const user=req.session.isAdmin ? req.session.isAdmin :false;
   
        res.render('signup', {
            pageTitle: 'Create our account',
            isAuthenticated: isAuthenticated,
            // user:user

        });
    
}




exports.postSignupForm = async(req, res) => {
   
  // const hashpassword=await bcrypt.hash(req.body.password,12);

    const model = new userModel({
      
        _id: mongoose.Types.ObjectId(),
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        email: req.body.email,
        password: req.body.password,
        role:req.body.Role,
       
    });
    //  console.log(model.password);
    
    model.save().then(addedCustomer => {
        res.redirect('/accounts/signin');
    });
}

exports.getSigninForm = (req, res) => {
    const isAuthenticated = req.session.isLoggedIn ? req.session.isLoggedIn : false;
    const user=req.session.isAdmin ? req.session.isAdmin :false;
    res.render('signin', {
        pageTitle: 'Login to your account',
        isAuthenticated: isAuthenticated,
            user:user
    });
}

exports.postSigninForm = (req, res) => {
    const userType =  req.body.Role;
    const admin = (userType === 'admin') ? true : false;
    userModel.findOne({
        email: req.body.email,
        password: req.body.password,
        role:req.body.Role,
        
    
    })
    .then(user => {
        if(user) {
            req.session.isLoggedIn = true,
            req.session.isAdmin = admin;
            req.session.user = user

            res.redirect('/');

        } else {
            res.redirect('/account/signin');
        }
    })

  
}


exports.postLogout = (req, res, next) => {
    req.session.destroy(err => {
      console.log(err);
      res.redirect('/');
    });
  };


